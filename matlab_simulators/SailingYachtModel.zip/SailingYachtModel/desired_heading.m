function desired_heading=f_traj(V_in2)
x = V_in2(4);
y = V_in2(5);

x_sp = 0;
y_sp = 300;

%verificar o �ngulo entre o ponto atual e o sp

%verifica a condi��o de bordejo

%c�digo para encontrar os pontos de bordejo

%retorna o desired_heading