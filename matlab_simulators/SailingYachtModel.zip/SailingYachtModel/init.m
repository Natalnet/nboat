%inicializar vari�veis
distanciaAlvo = 999999999;
w1 = [0;300];
w2 = [150;150];
w3 = [0;0];
waypoints = [w1 w2 w3];
waypointId = 1;
isBordejando = false;