#include "__cf_SailingYachtModel.h"
#include "SailingYachtModel_acc.h"
#include "SailingYachtModel_acc_private.h"
P_SailingYachtModel_T SailingYachtModel_rtDefaultP = { { 0.0 , 2.0 , 0.0 , -
1.5707963267948966 , 5.0 , 0.0 , 0.0 , 0.0 } , 0.0 , - 1.0 , { 0.0 , 1.0 ,
0.0 } , - 1.0 , 1.5707963267948966 , { 1.0 , 0.0 , 0.0 } , 0.0 , - 0.5 ,
1.0471975511965976 , - 1.0471975511965976 , 0.52359877559829882 , { 0.0 , 1.0
, 0.0 } , - 1.0 , 1.5707963267948966 } ;
