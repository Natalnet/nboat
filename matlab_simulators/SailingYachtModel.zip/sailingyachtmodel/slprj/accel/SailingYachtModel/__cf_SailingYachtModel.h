#ifndef CF_SailingYachtModel_H__
#define CF_SailingYachtModel_H__
#endif
