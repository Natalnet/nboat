#include "__cf_SailingYachtModel.h"
#ifndef RTW_HEADER_SailingYachtModel_acc_types_h_
#define RTW_HEADER_SailingYachtModel_acc_types_h_
#include "rtwtypes.h"
typedef struct P_SailingYachtModel_T_ P_SailingYachtModel_T ;
#endif
