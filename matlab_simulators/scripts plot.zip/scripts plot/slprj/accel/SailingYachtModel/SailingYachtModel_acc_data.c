#include "__cf_SailingYachtModel.h"
#include "SailingYachtModel_acc.h"
#include "SailingYachtModel_acc_private.h"
P_SailingYachtModel_T SailingYachtModel_rtDefaultP = { { 0.0 , 0.0 , 0.0 ,
0.0 , 3.0 , 0.0 , 0.0 , 0.0 } , 50.0 , 30.0 , 2.0 , 2.0 , 1.0471975511965976
, - 1.0471975511965976 , 3.1416 } ;
