% cd modelo-tese\Imagens\
print -painters -dpdf -r600 plotteste.pdf
% cd ..
% cd ..